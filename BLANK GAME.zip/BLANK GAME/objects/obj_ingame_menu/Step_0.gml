// ========================
// TOGGLE PAUSE (SEMPRE RODA)
// ========================
if (keyboard_check_pressed(vk_escape)) {
    global.paused = !global.paused;
}

// se não estiver pausado, para aqui
if (!global.paused) exit;


// ========================
// NAVEGAÇÃO
// ========================
if (keyboard_check_pressed(vk_up)) index--;
if (keyboard_check_pressed(vk_down)) index++;

if (index < 0) index = array_length(options) - 1;
if (index >= array_length(options)) index = 0;


// ========================
// SELEÇÃO
// ========================
if (keyboard_check_pressed(vk_enter)) {

    switch (index) {

        case 0: // RESUME
            global.paused = false;
        break;

        case 1: // MENU
            global.paused = false;
            room_goto(rm_menu);
        break;

        case 2: // EXIT
            game_end();
        break;
    }
}