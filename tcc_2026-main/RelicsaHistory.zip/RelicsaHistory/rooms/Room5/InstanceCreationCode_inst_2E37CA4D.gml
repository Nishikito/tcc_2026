text_id = "npcFilipe";
		