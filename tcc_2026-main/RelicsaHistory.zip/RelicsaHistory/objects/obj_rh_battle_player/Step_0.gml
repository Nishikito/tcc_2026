if (!instance_exists(obj_rh_battle_controller)) exit;
var _ctrl = obj_rh_battle_controller;

if (_ctrl.state == BATTLE_STATE.ENEMY_TURN) {
    visible = true;

    // ObjPlayer foi destruído — usa global.key_* sem conflito
    var _xspd = (keyboard_check(global.key_right) - keyboard_check(global.key_left)) * move_spd;
    var _yspd = (keyboard_check(global.key_down)  - keyboard_check(global.key_up))   * move_spd;

    // Fallback com setas físicas caso teclas remapeadas não respondam
    if (_xspd == 0 && _yspd == 0) {
        _xspd = (keyboard_check(vk_right) - keyboard_check(vk_left)) * move_spd;
        _yspd = (keyboard_check(vk_down)  - keyboard_check(vk_up))   * move_spd;
    }

    if (place_meeting(x + _xspd, y, obj_rh_battle_box)) {
        while (!place_meeting(x + sign(_xspd), y, obj_rh_battle_box)) x += sign(_xspd);
        _xspd = 0;
    }
    x += _xspd;

    if (place_meeting(x, y + _yspd, obj_rh_battle_box)) {
        while (!place_meeting(x, y + sign(_yspd), obj_rh_battle_box)) y += sign(_yspd);
        _yspd = 0;
    }
    y += _yspd;

    if (place_meeting(x, y, obj_rh_battle_bullet)) {
        var _dmg = calculate_enemy_damage();
        apply_damage_to_player(_dmg);
        with (obj_rh_battle_bullet) {
            if (place_meeting(other.x, other.y, id)) instance_destroy();
        }
    }

} else if (_ctrl.state == BATTLE_STATE.MENU
       ||  _ctrl.state == BATTLE_STATE.VICTORY
       ||  _ctrl.state == BATTLE_STATE.DEFEAT) {
    visible = true;
} else {
    visible = false;
}